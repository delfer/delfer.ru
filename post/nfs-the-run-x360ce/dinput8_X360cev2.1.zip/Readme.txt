This is for use with XBOX360 Controller Emulator.

v2.0 on 9/20/2009

This update contains 3 new versions.

Blocker - This will only allow the game to Enumerate Mouse and Keyboard.  This is using a new method which should work for most games that it didnt work with before.

Spoofer - This will spoof your all Controller names as "XBOX 360 Controller for Windows" which allows it to work for Mini Ninja's and may help with other games.

SpooferWIDECAR - This will do the same as above except its for peaple who use WIDE character, asian locale.

No need for registry editing.

Follow directions for XBOX360 Controller Emulator for usage.

This will work for any version of XBOX360 controller emulator.

v2.1 on 9/20/2009
Added device type fix to spoofer versions, reports controller as USB Gamepad, works with my G25 steering Wheel now.



Made by Racer_S http://tocaedit.com